'use client';

import { cn } from '@/lib/utils';

interface DigitPointerProps {
  digit: number | null;
  percentage: number;
  connected: boolean;
}

export function DigitPointer({ digit, percentage, connected }: DigitPointerProps) {
  const safe = Math.max(0, Math.min(100, percentage));
  return (
    <div className="rounded-2xl border bg-card/80 p-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Live digit pointer</div>
          <div className="text-sm font-medium">Moves with the latest Deriv tick</div>
        </div>
        <span className={cn('h-2.5 w-2.5 rounded-full', connected ? 'bg-emerald-500 animate-pulse' : 'bg-muted-foreground')} />
      </div>
      <div className="relative h-12 rounded-xl bg-muted/60 overflow-hidden">
        <div className="absolute inset-y-0 left-0 rounded-xl bg-primary/15 transition-[width] duration-300" style={{ width: `${safe}%` }} />
        <div className="absolute inset-y-0 transition-[left] duration-300" style={{ left: `calc(${safe}% - 1px)` }}>
          <div className="h-full w-0.5 bg-primary shadow-[0_0_10px_rgba(59,130,246,.7)]" />
          <div className="absolute -top-1 -translate-x-1/2 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-primary-foreground whitespace-nowrap">
            {digit ?? '—'} · {safe.toFixed(1)}%
          </div>
        </div>
        <div className="absolute inset-0 flex items-center justify-between px-2 text-[10px] text-muted-foreground pointer-events-none">
          <span>0</span><span>2</span><span>4</span><span>6</span><span>8</span><span>9</span>
        </div>
      </div>
    </div>
  );
}
