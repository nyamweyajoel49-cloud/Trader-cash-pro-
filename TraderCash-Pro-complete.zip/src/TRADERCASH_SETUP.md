# TraderCash Pro — setup and deployment

## What is included
- Live Deriv public tick connection for market data.
- Digit 0–9 frequency statistics and percentages.
- Moving live digit pointer driven by the selected digit's percentage.
- Matches/Differs, Over/Under and Even/Odd controls.
- Deriv OAuth/PKCE authentication flow.
- Account switching and balance synchronization.
- Contract proposal/buy flow and open/closed positions.
- Mobile-first UI.

## Important
The ZIP cannot contain your private Deriv credentials. Before real-money trading, configure your own Deriv OAuth application and HTTPS callback.

Set these environment variables on the HTTPS host:

NEXT_PUBLIC_DERIV_APP_ID=YOUR_DERIV_APP_ID
NEXT_PUBLIC_DERIV_REDIRECT_URI=https://YOUR-DOMAIN.example/
NEXT_PUBLIC_DERIV_ENV=production

The redirect URI must exactly match the callback registered in your Deriv OAuth application.

## Run
npm install
npm run build
npm start

## Safe first test
1. Deploy over HTTPS.
2. Open the site and confirm the live tick/digit percentages update.
3. Log in through Deriv OAuth.
4. Select a demo account first.
5. Confirm the balance and account label are correct.
6. Test proposals/contracts on demo before enabling real-money use.
